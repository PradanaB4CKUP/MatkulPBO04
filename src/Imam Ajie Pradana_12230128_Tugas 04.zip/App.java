public class App {
    public static void main(String[] args) throws Exception {
        DataMahasiswa Mhs = new DataMahasiswa();
        Mhs.InputData();
        Mhs.getProdi();
        Mhs.Cetak();
    }
}
